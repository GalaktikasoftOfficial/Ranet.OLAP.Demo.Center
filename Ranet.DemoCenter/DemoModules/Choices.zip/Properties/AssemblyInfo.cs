﻿using System.Reflection;
using System.Runtime.InteropServices;
using Ranet.Demo.Core;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("52372898-0594-4f9c-b5dd-2b37e73a8b33")]



[assembly: DemoModule("Choices and Integrations Widgets", 4)]
[assembly: DemoCategory("Metadata Choice Widget", 0)]
[assembly: DemoCategory("Member Choice Widget", 1)]
