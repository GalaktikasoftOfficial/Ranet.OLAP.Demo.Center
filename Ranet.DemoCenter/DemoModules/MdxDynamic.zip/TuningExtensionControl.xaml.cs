﻿using System.Windows.Controls;

namespace MdxDynamic
{
	/// <summary>
	/// Interaction logic for TuningExtensionControl.xaml
	/// </summary>
	public partial class TuningExtensionControl : UserControl
	{
		public TuningExtensionControl()
		{
			InitializeComponent();
		}
	}
}
